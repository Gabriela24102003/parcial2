package com.example.galeryparcial2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    ImageView vista1,envc1,envw12,galeriabt;
    private Uri elegirimg;


    private static final int REQUEST_SELECT_IMAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vista1 = findViewById(R.id.vista);
        envc1 = findViewById(R.id.evng);
        envw12 = findViewById(R.id.evnw);
        galeriabt = findViewById(R.id.ftgaleria);


        envw12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (elegirimg == null) {
                    Toast.makeText(MainActivity.this, "Elija una imagen primero", Toast.LENGTH_SHORT).show();
                } else {
                    envwap(elegirimg);
                }
            }
        });
        envc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (elegirimg == null) {
                    Toast.makeText(MainActivity.this, "Elija una imagen primero", Toast.LENGTH_SHORT).show();
                } else {
                    enviarcorreo(elegirimg);
                }
            }

        });




        galeriabt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_SELECT_IMAGE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_SELECT_IMAGE && resultCode == RESULT_OK && data != null) {
            elegirimg = data.getData();
            vista1.setImageURI(elegirimg);
            envc1.setEnabled(true);
            envw12.setEnabled(true);
        }
    }


    private void enviarcorreo(Uri elegirimg) {
        Intent intentCorreo = new Intent(Intent.ACTION_SEND);
        intentCorreo.setType("image/*");
        intentCorreo.putExtra(Intent.EXTRA_STREAM, elegirimg);
        intentCorreo.setPackage("com.google.android.gm");
        startActivity(Intent.createChooser(intentCorreo, "Compartir imagenes"));


    }

    private void envwap(Uri elegirimg) {
        Intent intentWhat = new Intent(Intent.ACTION_SEND);
        intentWhat.setType("image/*");
        intentWhat.putExtra(Intent.EXTRA_STREAM, elegirimg);
        intentWhat.setPackage("com.whatsapp");
        startActivity(Intent.createChooser(intentWhat, "Compartir imagenes"));

    }















}
